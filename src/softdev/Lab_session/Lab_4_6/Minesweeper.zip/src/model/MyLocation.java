package model;

import gameinterface.Location;

public class MyLocation implements Location {
    private int Row;
    private int Column;
    private String content;
    private boolean type;

    public MyLocation(int Column, int Row) {
        this.Column = Column;
        this.Row = Row;
    }

    public int getColumn() {
        return Column;
    }

    public int getRow() {
        return Row;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isType() {
        return type;
    }

    public void setType(boolean type) {
        this.type = type;
    }
}
