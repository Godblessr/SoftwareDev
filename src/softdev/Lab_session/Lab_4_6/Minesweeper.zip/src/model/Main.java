package model;

import gameinterface.InvalidRangeException;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        {
            MyMinesweeper game = new MyMinesweeper(1);
            game.printBoard();
            try {
                game.checkGame();
            } catch (InvalidRangeException e) {
                e.printStackTrace();
            }

            Scanner scan = new Scanner(System.in);
            while (game.state) {
                System.out.print("X：");
                int x = scan.nextInt()-1;
                System.out.print("Y：");
                int y = scan.nextInt()-1;
                game.checkLocation(new MyLocation(x, y));
                game.printBoard();
                if (game.getVictory()) {
                } else {
                    game.printBoard();
                    break;
                }
                game.Step++;
            }
        }
    }
}
