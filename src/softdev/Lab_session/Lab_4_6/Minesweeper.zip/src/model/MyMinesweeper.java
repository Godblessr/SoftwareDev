package model;

import gameinterface.InvalidRangeException;
import gameinterface.MineSweeperModel;

import java.awt.*;
import java.util.Random;

public class MyMinesweeper implements MineSweeperModel {
    public int Width;
    public int Mine = 0;
    public int Height;
    public MyLocation[][] Location;
    public boolean state = true;
    public int LeftMine;
    public int Step = 0;
    public int count;

    public MyMinesweeper(int Mode) {
        if (Mode == 1) {
            Width = 10;
            Height = 10;
            Mine = 10;
            System.out.println("Beginner Mode:10*10 with 10 Mines");

        } else if (Mode == 2) {
            Width = 16;
            Height = 16;
            Mine = 40;
            System.out.println("Intermediate Mode:16*16 with 40 Mines");
        } else if (Mode == 3) {
            Width = 30;
            Height = 16;
            Mine = 99;
            System.out.println("Expert Mode:16*30 with 99 Mines");
        }
        count = Mine;
        LeftMine = Mine;
        iniMine(Height, Width, Mine);
    }

    public MyMinesweeper(int Height, int Width) throws InvalidRangeException {
        this.Height = Height;
        this.Width = Width;
        Mine = 0;

    }

    public MyMinesweeper(int Height, int Width, int Mine) throws InvalidRangeException {
        this.Height = Height;
        this.Width = Width;
        this.Mine = Mine;
        count = Mine;
        LeftMine = Mine;
        iniMine(Height, Width, Mine);

    }

    public int getWidth() {
        return Width;
    }

    public int getHeight() {
        return Height;
    }

    public Point[] getPoint(int x, int y) {
        Point[] point = new Point[8];
        point[0] = new Point(x - 1, y);
        point[1] = new Point(x - 1, y - 1);
        point[2] = new Point(x, y - 1);
        point[3] = new Point(x + 1, y - 1);
        point[4] = new Point(x + 1, y);
        point[5] = new Point(x + 1, y + 1);
        point[6] = new Point(x, y + 1);
        point[7] = new Point(x - 1, y + 1);
        return point;
    }

    @Override
    public void checkLocation(MyLocation location) {
        int x = location.getRow();
        int y = location.getColumn();
        Location[x][y].setType(true);
        if (!Location[x][y].getContent().equals("[*]")) {
            if (Location[x][y].getContent().equals("[ ]") ){
                Point[] p = this.getPoint(x, y);
                for (Point point : p) {
                    if (point.x >= 0 && point.x < Width && point.y >= 0 && point.y < Height) {
                        if (Location[point.x][point.y].getContent().equals("[ ]") && !Location[point.x][point.y].isType()) {
                            this.checkLocation(Location[point.x][point.y]);
                        } else {
                            Location[point.x][point.y].setType(true);
                        }
                    }
                }
            }
        } else {
            System.out.println("You Lose! Game Over!");
            state = getLost();
            for (int i = 0; i < Location.length; i++) {
                for (int j = 0; j < Location[i].length; j++) {
                    Location[i][j].setType(true);
                }
            }
        }
    }


    @Override
    public void flagLocation(MyLocation location) {

    }

    public int getNrOfActions() {
        return Step;
    }

    public long getNrOfMinesLeft() {
        return LeftMine;
    }

    public boolean getLost() {
        return false;
    }

    public void printBoard() {
        for (int i = 0; i < Location.length + 1; i++) {
            System.out.print(i+" ");
        }
        System.out.println();
        for (int i = 0; i < Location.length; i++) {
            System.out.print(i + 1+" ");
            for (int j = 0; j < Location[i].length; j++) {
                //
                if (Location[i][j].isType()) {
                    System.out.print(Location[i][j].getContent() + " ");
                } else {
                    System.out.print("■ ");
                }
            }
            System.out.println();
        }
        System.out.println("nr of actions: " + getNrOfActions() + " :: mines to go: " + getNrOfMinesLeft());
    }

    public void checkGame() throws InvalidRangeException {
        if (getHeight() <= 0 || getWidth() <= 0) {
            throw new InvalidRangeException("A different Exception has been trown");
        } else if (getHeight() * getWidth() <= Mine) {
            throw new InvalidRangeException("Expected an InvalidRangeException to be thrown");
        } else if (Mine == 0) {
            throw new InvalidRangeException("No InvalidRangeException expected");
        }
    }

    public void iniMine(int width, int height, int mine) {
        count=mine;
        Location = new MyLocation[width][height];
        for (int i = 0; i < Location.length; i++) {
            for (int j = 0; j < Location[i].length; j++) {
                Location[i][j] = new MyLocation(i, j);
                Location[i][j].setContent("[ ]");
                Location[i][j].setType(false);

            }
        }
        Random r = new Random();
        do {
            int x = r.nextInt(width);
            int y = r.nextInt(height);
            if (!Location[x][y].getContent().equals("[*]")) {
                Location[x][y].setContent("[*]");
                count--;
            }
        } while (count > 0);

        for (int i = 0; i < Location.length; i++) {
            for (int j = 0; j < Location[i].length; j++) {

                int sum = 0;
                if (!Location[i][j].getContent().equals("[*]")) {
                    Point[] p = this.getPoint(i, j);
                    for (Point point : p) {
                        if (point.x >= 0 && point.x < Width && point.y >= 0 && point.y < Height) {
                            if (Location[point.x][point.y].getContent().equals("[*]")) {
                                sum++;
                            }
                        }
                    }
                    if (sum > 0) {
                        Location[i][j].setContent(String.valueOf(sum));
                    }
                }
            }
        }
    }

    public boolean getVictory() {
        int number = 0;
        for (int i = 0; i < Location.length; i++) {
            for (int j = 0; j < Location[i].length; j++) {
                if (!Location[i][j].isType()) {
                    number++;
                }
            }
        }
        if (number == LeftMine) {
            for (int i = 0; i < Location.length; i++) {
                for (int j = 0; j < Location[i].length; j++) {
                    Location[i][j].setType(true);
                }
            }
            System.out.println("You win!");
            return false;
        } else {
            return true;
        }
    }
}