package gameinterface;

import model.MyLocation;

/**
 * MineSweeper model interface, to make it easier to attach whatever kind of UI or test class to the game
 */
public interface MineSweeperModel {
    /**
     * Returns the width of the game board
     * @return width of board
     */
    int getWidth();

    /**
     * Returns the height of the game board
     * @return height of board
     */
    int getHeight();

    /**
     * Method to fire a checkLocation on a cell on the game board
     * @param location the location of the cell with row and column
     */
    void checkLocation(MyLocation location);

    /**
     * Method to fire a flagLocation on a cell on the game board
     * @param location the location of the cell with row and column
     */
    void flagLocation(MyLocation location);
    /**
     * The number of actions so far
     * @return the number of clicks
     */
    int getNrOfActions();

    /**
     * The number of mines left uncovered by a flag
     * @return the number of mines to discover
     */
    long getNrOfMinesLeft();

    /**
     * Method to indicate the game is lost (by clicking a mine)
     * @return true if the game is lost
     */
   public boolean getLost();

}
