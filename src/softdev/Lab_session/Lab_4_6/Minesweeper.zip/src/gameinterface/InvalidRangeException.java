package gameinterface;

public class InvalidRangeException extends Exception {
    public InvalidRangeException(String message) {
        super(message);
    }

    public InvalidRangeException() {
    }
}
