package gameinterface;

public interface Location {

    int getColumn();

    int getRow();
}
